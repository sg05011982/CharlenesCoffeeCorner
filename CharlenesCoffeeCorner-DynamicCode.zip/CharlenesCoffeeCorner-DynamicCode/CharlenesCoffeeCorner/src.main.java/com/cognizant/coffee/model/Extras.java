package com.cognizant.coffee.model;

import java.util.HashMap;
import java.util.Map;

public enum Extras {
	Extra_Milk("extra_milk", "extras",0.30),
	Foamed_Milk("foamed_milk","extras", 0.50),
	Roast_Coffee("roast_coffee","extras", 0.90);
	
	String name;
	String type;
	double price;
	
	
	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getType() {
		return type;
	}

	public void setType(String type) {
		this.type = type;
	}

	public double getPrice() {
		return price;
	}

	public void setPrice(double price) {
		this.price = price;
	}

	private Extras(String name, String type, double price) {
		this.name = name;
		this.type = type;
		this.price = price;
	}
	
public static final Map<String, Extras> extraMap = new HashMap<>();
	
	static{
		for(Extras extra: values()){
			extraMap.put(extra.name, extra);
		}
	}
	
}
