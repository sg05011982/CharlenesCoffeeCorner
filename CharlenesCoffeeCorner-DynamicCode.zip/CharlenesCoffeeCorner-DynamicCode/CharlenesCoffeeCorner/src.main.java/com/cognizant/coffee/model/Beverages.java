package com.cognizant.coffee.model;

import java.util.HashMap;
import java.util.Map;

public enum Beverages {

	Small_Coffee("small_coffee", "beverage",2.50),
	Medium_Coffee("medium_coffee","beverage", 3.00),
	Large_coffee("large_coffee","beverage", 3.50);
	
	String name;
	String type;
	double price;
	

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getType() {
		return type;
	}

	public void setType(String type) {
		this.type = type;
	}

	public double getPrice() {
		return price;
	}

	public void setPrice(double price) {
		this.price = price;
	}
	
	private Beverages(String name, String type, double price) {
		this.name = name;
		this.type = type;
		this.price = price;
	}
	
	public static final Map<String, Beverages> beverageMap = new HashMap<>();
	
	static{
		for(Beverages bev: values()){
			beverageMap.put(bev.name, bev);
		}
	}
	
	
}
