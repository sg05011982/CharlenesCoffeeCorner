package com.cognizant.coffee;

import java.util.List;

public interface Bills {
	/**
	 * Show Menu - to list all the offered items 
	 */
	public void showMenu();
	
	/**
	 * Generate Bill - Generate the Bill for items purchased
	 * 
	 * @param list - list items
	 * @return
	 */
	public double generateBill(List<String> list);

}
