import static org.junit.Assert.assertEquals;

import java.util.ArrayList;
import java.util.List;

import org.junit.Test;

import com.cognizant.coffee.Bills;
import com.cognizant.coffee.CoffeeMenu;

public class test {

	@SuppressWarnings("deprecation")
	@Test
	public void testBill1() {
		Bills bill = new CoffeeMenu();
		List<String> list = new ArrayList<>();
		list.add("1-Small_Coffee");
		list.add("1-Large_Coffee");
		list.add("1-Extra_Milk");
		list.add("1-Roast_Coffee");
		list.add("1-Bacon_Roll");
		list.add("1-Orange_Juice");
		assertEquals(15.35,bill.generateBill(list),0.5);
	}
	
	public void testBill2() {
		Bills bill = new CoffeeMenu();
		List<String> list = new ArrayList<>();
		list.add("5-Small_Coffee");
		list.add("13-Large_Coffee");
		list.add("2-Extra_Milk");
		list.add("1-Orange_Juice");
		assertEquals(55.05,bill.generateBill(list),0.5);
	}
	
	public void testBill3() {
		Bills bill = new CoffeeMenu();
		List<String> list = new ArrayList<>();
		list.add("5-Small_Coffee");
		list.add("13-Large_Coffee");
		list.add("2-Extra_Milk");
		list.add("2-Orange_Juice");
		list.add("2-Bacon_Roll");
		assertEquals(67.4,bill.generateBill(list),0.0);
	}

}
