import java.util.ArrayList;
import java.util.List;

import com.cognizant.coffee.Bills;
import com.cognizant.coffee.CoffeeMenu;

public class DemoCoffeeCorner {

	/**
	 * assumption made
	 * Discount given is with respect to the least price in the section
	 * Not tracking user for stamp card process (will not remember if he visit again)
	 * Names should be as per the Document and it should follow positive number separated by "-"
	 * 
	 * List of products
	 * 	Small_Coffee
	 *  Large_Coffee
	 *  Medium_Coffee
	 *  Orange_Juice
	 *  Bacon_Roll
	 *  Extra_Milk
	 *  Foamed_Milk
	 *  Roast_Coffee
	 * 
	 * Exception handling is at very minimal level and also formatting can be done better
	 */
	
	public static void main(String[] args) {
		
		Bills bill = new CoffeeMenu();
		List<String> list = new ArrayList<>();
		list.add("5-Small_Coffee");
		list.add("13-Large_Coffee");
		list.add("2-Extra_Milk");
		list.add("2-Orange_Juice");
		list.add("2-Bacon_Roll");
		bill.generateBill(list);
	}

}
