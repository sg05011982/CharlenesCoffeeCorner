package com.cognizant.coffee;

import java.util.List;

public interface Bills {
	public double generateBill(List<String> list);

}
