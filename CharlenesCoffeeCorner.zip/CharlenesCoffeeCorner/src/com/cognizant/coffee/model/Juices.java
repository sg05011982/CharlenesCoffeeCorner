package com.cognizant.coffee.model;

import java.util.HashMap;
import java.util.Map;

public enum Juices {
	Orange_Juice("Orange_Juice", "juice",3.95);
	
	String name;
	String type;
	double price;
	
	
	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getType() {
		return type;
	}

	public void setType(String type) {
		this.type = type;
	}

	public double getPrice() {
		return price;
	}

	public void setPrice(double price) {
		this.price = price;
	}

	private Juices(String name, String type, double price) {
		this.name = name;
		this.type = type;
		this.price = price;
	}
	
public static final Map<String, Juices> juiceMap = new HashMap<>();
	
	static{
		for(Juices juice: values()){
			juiceMap.put(juice.name, juice);
		}
	}
}
