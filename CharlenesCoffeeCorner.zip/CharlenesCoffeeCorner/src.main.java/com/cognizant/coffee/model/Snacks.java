package com.cognizant.coffee.model;

import java.util.HashMap;
import java.util.Map;

public enum Snacks {
	Bacon_Roll("Bacon_Roll", "snack",4.50);
	
	String name;
	String type;
	double price;
	
	private Snacks(String name, String type, double price) {
		this.name = name;
		this.type = type;
		this.price = price;
	}
	

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getType() {
		return type;
	}

	public void setType(String type) {
		this.type = type;
	}

	public double getPrice() {
		return price;
	}

	public void setPrice(double price) {
		this.price = price;
	}
	
public static final Map<String, Snacks> snackMap = new HashMap<>();
	
	static{
		for(Snacks snack: values()){
			snackMap.put(snack.name, snack);
		}
	}
}
