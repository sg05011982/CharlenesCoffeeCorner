package com.cognizant.coffee;

import static com.cognizant.coffee.model.Beverages.beverageMap;
import static com.cognizant.coffee.model.Extras.extraMap;
import static com.cognizant.coffee.model.Juices.juiceMap;
import static com.cognizant.coffee.model.Snacks.snackMap;

import java.text.DecimalFormat;
import java.util.ArrayList;
import java.util.List;

import com.cognizant.coffee.model.Offering;

public class CoffeeMenu implements Bills{

	@Override
	public double generateBill(List<String> list) {
		try{
			System.out.println("====================="+list);
		double total_sum = 0;
		double bevDiscount = 0;
		double extraDiscount = 0;
		double totalDiscount = 0;
		List<Offering> list_offering = new ArrayList<>();
		int bevCounter = 0;
		int juiceCounter = 0;
		int snackCounter = 0;
		int extraCounter = 0;
		for(String item : list){
			int quantity = Integer.parseInt(item.split("-")[0]);
			String name = item.split("-")[1];
			String type = null;
			double price = 0;
			if(beverageMap.containsKey(name)){
				bevCounter = bevCounter + quantity;
				type = beverageMap.get(name).getType();
				price =  beverageMap.get(name).getPrice();
			}else if(juiceMap.containsKey(name)){
				juiceCounter = juiceCounter+quantity;
				type = juiceMap.get(name).getType();
				price =  juiceMap.get(name).getPrice();
			}else if(extraMap.containsKey(name)){
				extraCounter = extraCounter + quantity;
				type = extraMap.get(name).getType();
				price =  extraMap.get(name).getPrice();
			}else if(snackMap.containsKey(name)){
				snackCounter = snackCounter+ quantity;
				type = snackMap.get(name).getType();
				price =  snackMap.get(name).getPrice();
			}else{
				System.out.println("=================Invalid Offering=================");
				continue;
			}
			double total_price = quantity * price; 
			total_sum = total_sum+total_price; 
			Offering offering = new Offering(name,type,quantity,total_price);
			list_offering.add(offering);
		}
		if(bevCounter > 4){
			int disc = bevCounter / 5;
			bevDiscount = 2.5 * disc;
		}
		if(juiceCounter > 0 && snackCounter > 0 && extraCounter > 0){
			int quantity = 0;
			if(juiceCounter > snackCounter){
				quantity = snackCounter;
			}else{
				quantity = juiceCounter;
			}
			if(quantity>extraCounter){
				extraDiscount = 0.30 * extraCounter;
			}else{
				extraDiscount = 0.30 * quantity;
			}
		}
		totalDiscount = extraDiscount+bevDiscount;
		printBill(list_offering, total_sum, totalDiscount);
		return total_sum-totalDiscount;
		}catch(Exception ex){
			System.out.println("Exception Occurred=================="+ex);
			return 0.0;
		}
	}

	private void printBill(List<Offering> list_offering, double total_sum, double discount) {
		DecimalFormat ft = new DecimalFormat("#.##");
		if(list_offering.size()>0){
			System.out.println("=========================================================");
			System.out.println("Name===============Type============Quantity=========Price");
		for(Offering offerings: list_offering){
			System.out.println(offerings.toString());
		}
		System.out.println("Total Discounts================"+ft.format(discount));
		System.out.println("=====================================================");
		System.out.println("Total Bill after Discounts================"+ft.format(total_sum-discount));
		}
	}

	@Override
	public void showMenu() {
		System.out.println(" List of products \n"+
	 	"  Small_Coffee\n "+
	    "  Large_Coffee\n "+
	    "  Medium_Coffee\n "+
	    "  Orange_Juice \n"+
	    "  Bacon_Roll \n"+
	    "  Extra_Milk \n"+
	    "  Foamed_Milk \n"+
	    "  Roast_Coffee");
		System.out.println("\n");
		System.out.println("Offers Running, Hurry Up !!!");
		System.out.println("=========================================================");
		System.out.println("Every 5th beverae is for FREE !!!");
		System.out.println("Every Snack + Juice, One of the Extra is for FREE !!! ");
		System.out.println("=========================================================");
		// TODO Auto-generated method stub
	}

}
