import static org.junit.Assert.*;

import java.util.ArrayList;
import java.util.List;

import org.junit.Test;

import com.cognizant.coffee.Bills;
import com.cognizant.coffee.CoffeeMenu;

public class CoffeeTest {

	@Test
	public void testCombo1Bill() {
		Bills bill = new CoffeeMenu();
		List<String> list = new ArrayList<>();
		list.add("5-Small_Coffee");
		assertEquals(10,bill.generateBill(list), 0.5);
	}
	
	@Test
	public void testCombo1And2Bill() {
		Bills bill = new CoffeeMenu();
		List<String> list = new ArrayList<>();
		list.add("1-Small_Coffee");
		list.add("1-Large_Coffee");
		list.add("3-Medium_Coffee");
		list.add("1-Extra_Milk");
		list.add("1-Roast_Coffee");
		list.add("1-Bacon_Roll");
		list.add("1-Orange_Juice");
		assertEquals(21.85,bill.generateBill(list), 0.5);
	}
	
	@Test
	public void testCombo2Bill() {
		Bills bill = new CoffeeMenu();
		List<String> list = new ArrayList<>();
		list.add("2-Extra_Milk");
		list.add("2-Orange_Juice");
		list.add("2-Bacon_Roll");
		assertEquals(16.9,bill.generateBill(list), 0.5);
	}

}
